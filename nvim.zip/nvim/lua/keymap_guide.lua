﻿-- =================================================================
-- | keymap_guide.lua - MODUŁ INTERAKTYWNY (LazyVim / Gruvbox Czysty)|
-- | PEŁNA WERSJA SKRYPTU Z NAWIGACJĄ <Tab> i <S-Tab>                |
-- =================================================================

local M = {}

-- ==============================
-- 1. Zmienne globalne i Dane
-- ==============================
local current_tab = 1
local bufnr_guide = nil
local last_cursor_line = 0   -- Zmienna do śledzenia kursora po ruchu j/k
local interactive_lines = {} -- Lokalna tablica linii interaktywnych (0-based index)

-- Definicja zakładek
local TABS = {
    "VIM GŁÓWNE",
    "EDYCJA/TEKST",
    "POMOC",
    "KONFIGURACJA",
    "WYSZUKIWANIE",
    "GIT/CODE",
    "DEBUG",
}

-- Zawartość każdej zakładki (Rozbudowane dane)
local GUIDE_CONTENT = {
    ["VIM GŁÓWNE"] = {
        header = {
            "**[ Pomiedzy załadkami można się poruszać klawiszami 'K' i 'L']**",
            "Tryb Normalny (N) jest domyślny. Tryb Wstawiania (I) dla edycji. Zawsze wracaj do N!",
        },
        sections = {
            {
                title = "ZARZĄDZANIE SESJĄ I PLIKAMI",
                content = {
                    { ":q",        "Zamknij bieżący bufor (jeśli niezmieniony)" },
                    { ":q!",       "Zamknij bez zapisywania (ignoruj zmiany)" },
                    { ":w",        "Zapisz bieżący bufor" },
                    { ":wq",       "Zapisz i wyjdź" },
                    { ":e {file}", "Otwórz nowy plik w bieżącym oknie" },
                    { ":e!",       "Przeładuj plik z dysku (ignorując zmiany w buforze)" },
                    { ":source %", "Przeładuj bieżący plik konfiguracyjny (np. init.lua)" },
                },
            },
            {
                title = "RUCH I ZNACZNIKI (MOVE & JUMP)",
                content = {
                    { "H/M/L",       "Przeskocz do Góry/Środka/Dołu widocznego ekranu (High/Middle/Low)" },
                    { "w / e / b",   "Skok o słowo do przodu (word) / do końca słowa / do tyłu" },
                    { "{ / }",       "Skok o akapit w górę/dół" },
                    { "^ / $",       "Skok na początek (pierwszy znak) / koniec linii" },
                    { "0 / _",       "Skok na absolutny początek linii / pierwszy widoczny znak" },
                    { "gg / G",      "Skok na początek / koniec pliku" },
                    { "<C-o>/<C-i>", "Skok po historii pozycji (Jump List) - cofnij / ponów" },
                    { "f/t{char}",   "Szukaj znaku na linii (Find/To), użyj ; / , by powtórzyć/cofnąć" },
                },
            },
        },
    },
    ["EDYCJA/TEKST"] = {
        header = {
            "**[ EDYCJA/TEKST: Operatory i Obiekty Tekstowe ]**",
            "Operatory: **d** (delete), **c** (change), **y** (yank). Powtórzenie: **.** (kropka)",
        },
        sections = {
            {
                title = "OPERACJE TEKSTOWE I WSTAWIENIE",
                content = {
                    { "d{ruch}",   "Usuń (delete) od kursora do {ruch}" },
                    { "c{ruch}",   "Zmień (change) i przejdź do Trybu Wstawiania" },
                    { "y{ruch}",   "Skopiuj (yank) od kursora do {ruch}" },
                    { "p / P",     "Wklej (put) zawartość rejestru (po / przed kursorem)" },
                    { "o / O",     "Otwórz nową linię poniżej / powyżej (Insert Mode)" },
                    { "u / <C-z>", "Cofnij (undo) / Ponów (redo)" },
                    { ".",         "Powtórz ostatnią operację edycyjną" },
                },
            },
            {
                title = "OBIEKTY TEKSTOWE (TEXT OBJECTS) - UŻYCIE W V/C/D/Y",
                content = {
                    { "dd / yy",    "Usuń / Kopiuj całą linię" },
                    { "dw / cw",    "Usuń / Zmień słowo" },
                    { "daw / ciw",  "Usuń całe słowo (a word) / Zmień wewnątrz słowa (inner word)" },
                    { "dap / cip",  "Usuń / Zmień akapit (paragraph)" },
                    { "das / cis",  "Usuń całe zdanie / Zmień wewnątrz zdania" },
                    { "da\" / ci'", "Usuń w cudzysłowie / Zmień w apostrofie" },
                    { "va{ / vi[",  "Wybierz trybem wizualnym: blok z nawiasami klamrowymi / wewnątrz kwadratowych" },
                },
            },
            {
                title = "TRYBY WIZUALNE I INNE",
                content = {
                    { "v",       "Tryb wizualny znakowy (Visual Mode)" },
                    { "V",       "Tryb wizualny liniowy (Visual Line Mode)" },
                    { "<C-v>",   "Tryb wizualny blokowy (Visual Block Mode)" },
                    { ">> / <<", "Zwiększ / Zmniejsz wcięcie linii (w trybie Normalnym lub Wizualnym)" },
                    { "gq",      "Formatuj tekst zgodnie z `textwidth` (w Trybie Wizualnym)" },
                },
            },
        },
    },
    ["POMOC"] = {
        header = {
            "**[ POMOC: GŁÓWNY PRZEWODNIK I Narzędzia ]**",
            "Użyj **<C-y>** (CTRL+Y), by otworzyć **WHICH-KEY** w dowolnym momencie",
        },
        sections = {
            {
                title = "MENU I WŁĄCZNIKI (ENTER - Interaktywne)",
                content = {
                    { "<leader>ce",    "Edytuj plik init.lua (otworzy konfigurację Nvim)" },
                    { "<leader>cs",    "Przeładuj plik init.lua (source) - użyj po edycji" },
                    { "<leader>e",     "Pokaż/Ukryj Eksplorator (NvimTree)" },
                    { "<leader>t",     "Terminal (ToggleTerm) - przełącz w trybie normalnym" },
                    { ":CheckHealth",  "Sprawdź stan zainstalowanych narzędzi Nvim" },
                    { ":help {topic}", "Wbudowana pomoc Vima/Neovima" },
                    { ":Clear",        "Usuwa historie otwartych plików" }
                },
            },
            {
                title = "NAWIGACJA OKIEN I BUFORÓW",
                content = {
                    { "<C-w>h/j/k/l", "Przejdź do sąsiedniego okna" },
                    { "<C-w>=",       "Wyrównaj rozmiary wszystkich okien" },
                    { "<C-w>o",       "Zamknij wszystkie okna oprócz bieżącego (one)" },
                    { "<leader>bb",   "Lista otwartych buforów (Telescope Buffer)" },
                    { "<leader>bn",   "Następny bufor, <leader>bp Poprzedni" },
                    { "zz",           "Wyśrodkuj widok na kursorze (utrzymanie linii widocznej)" },
                    { ":bdel",        "Usuń bieżący bufor (bez zamykania okna)" },
                },
            },
        },
    },
    ["KONFIGURACJA"] = {
        header = {
            "**[ KONFIGURACJA: Zarządzanie Narzędziami i Środowiskiem ]**",
            "Ustawienia pluginów i środowiska programistycznego.",
        },
        sections = {
            {
                title = "MENADŻER KLUCZY I PLUGINY (ENTER - Interaktywne)",
                content = {
                    { "<leader>h",            "Pełny przewodnik Which-Key (pokazuje wszystkie mapowania)" },
                    { ":Lazy",                "Otwórz Lazy.nvim (Menadżer pluginów)" },
                    { ":Mason",               "Otwórz Mason (Menadżer LSP/Formatterów/Lintersów)" },
                    { ":UpdateRemotePlugins", "Aktualizuj zdalne pluginy (dla Nvim)" },
                    { ":TSUpdate",            "Aktualizuj parsery Tree-sitter" },
                },
            },
            {
                title = "OKNA, PODZIAŁY I WIDOKI",
                content = {
                    { "<C-w>v",       "Podziel okno pionowo (`:vsplit`)" },
                    { "<C-w>s",       "Podziel okno poziomo (`:split`)" },
                    { "<C-w>c",       "Zamknij bieżące okno (`:close`)" },
                    { "<C-w>r",       "Rotuj oknami (zmiana układu)" },
                    { "<C-w>H/J/K/L", "Przenieś aktywne okno w danym kierunku" },
                    { "<C-w>> / <",   "Zmień szerokość / wysokość okna" },
                },
            },
        },
    },
    ["WYSZUKIWANIE"] = {
        header = {
            "**[ WYSZUKIWANIE: Telescope, Grep i Wewnętrzne Mechanizmy ]**",
            "Szybkie skoki do plików, symboli i zawartości.",
        },
        sections = {
            {
                title = "TELESCOPE I GREP - SZUKAJ WSZYSTKIEGO",
                content = {
                    { "<leader>ff", "Znajdź pliki w projekcie (Find Files)" },
                    { "<leader>fb", "Ostatnio otwarte pliki (Buffer History)" },
                    { "<leader>fg", "Wyszukaj tekst w plikach (Live Grep)" },
                    { "<leader>fw", "Słowo pod kursorem (Word search)" },
                    { "<leader>fc", "Historia komend i ostatnie skoki" },
                    { "<leader>fs", "Wyszukaj symbole (tylko w bieżącym buforze)" },
                    { "<leader>gs", "Wyszukaj status Git w projekcie" },
                },
            },
            {
                title = "WEWNĘTRZNE WYSZUKIWANIE VIM I ZAMIANA",
                content = {
                    { "/, ?",           "Szukaj przód/tył (zapisuje w historii)" },
                    { "n, N",           "Następne/Poprzednie wystąpienie" },
                    { "*, #",           "Szukaj słowa pod kursorem (w przód/w tył)" },
                    { "g*",             "Szukaj części słowa (np. `car` znajdzie `carpet`)" },
                    { ":s/old/new/g",   "Zamień (substitute) 'old' na 'new' w bieżącej linii globalnie" },
                    { ":%s/old/new/gc", "Zamień w całym pliku z potwierdzeniem ('c' - confirm)" },
                    { ":g/pattern/d",   "Usuń wszystkie linie pasujące do wzorca ('global delete')" },
                },
            },
        },
    },
    ["GIT/CODE"] = {
        header = {
            "**[ GIT/CODE: Kontrola Wersji, LSP i Refaktoryzacja ]**",
            "Integracja z GitSigns i Language Server Protocol (LSP).",
        },
        sections = {
            {
                title = "GIT SIGNS (Integracja) - ENTER",
                content = {
                    { "<leader>gs",  "Otwórz szybkie menu GitSigns (staging/hunk actions)" },
                    { "[g / ]g",     "Skocz do Poprzedniej / Następnej zmiany Git" },
                    { "<leader>ghr", "Przywróć (revert) Hunk (fragment kodu)" },
                    { "<leader>gss", "Staging (dodanie do poczekalni) bieżącego pliku" },
                    { "<leader>ghp", "Podgląd (Peek) hanka (fragmentu) kodu" },
                    { "<leader>gb",  "Pokaż autora linii (Git Blame)" },
                },
            },
            {
                title = "LSP (Language Server Protocol)",
                content = {
                    { "gd",         "Idź do definicji (Go to Definition)" },
                    { "gD",         "Idź do deklaracji (Go to Declaration)" },
                    { "gi",         "Idź do implementacji (Go to Implementation)" },
                    { "gr",         "Znajdź referencje (References)" },
                    { "K",          "Dokumentacja (Hover/Signature)" },
                    { "<leader>lr", "Zmień nazwę symbolu (Rename)" },
                    { "<leader>lc", "Szybkie akcje kodu (Code Action)" },
                    { "[d / ]d",    "Skocz do Poprzedniej / Następnej diagnostyki" },
                },
            },
        },
    },
    ["DEBUG"] = {
        header = {
            "**[ DEBUG: Debug Adapter Protocol (DAP) ]**",
            "Kontrolowanie i inspekcja kodu źródłowego przy użyciu Nvim-dap.",
        },
        sections = {
            {
                title = "DEBUGOWANIE (DAP) - W TRYBIE NORMALNYM",
                content = {
                    { "<leader>dc", "Kontynuuj / Start / Stop sesji debugowania" },
                    { "<leader>db", "Przełącz breakpoint na bieżącej linii" },
                    { "<leader>do", "Krok Nad (Step Over) - wykonaj bieżącą linię" },
                    { "<leader>di", "Krok Wgłąb (Step Into) - wejdź do funkcji" },
                    { "<leader>du", "Krok Wyjdź (Step Out)" },
                    { "<leader>dK", "Pokaż wartość zmiennej pod kursorem (Hover)" },
                },
            },
            {
                title = "ZARZĄDZANIE PANELEM DAP",
                content = {
                    { "<leader>dt", "Pokaż/Ukryj główny panel debugowania" },
                    { "<leader>dw", "Pokaż/Ukryj okno Watch (obserwowane zmienne)" },
                    { "<leader>dr", "Pokaż/Ukryj okno Pamięci (Registers)" },
                    { "<leader>dl", "Wyświetl logi debugowania" },
                    { "<leader>de", "Oceniaj wyrażenie/zmienną pod kursorem" },
                    { "<leader>dP", "Pokaż Call Stack (stos wywołań)" },
                },
            },
        },
    },
}

-- ==============================
-- 2. Definicja kolorów (Gruvbox)
-- ==============================
local function define_highlights()
    -- Gruvbox Palette (Dark)
    pcall(vim.api.nvim_set_hl, 0, "GuideHeader", { fg = "#fe8019", bold = true })
    pcall(vim.api.nvim_set_hl, 0, "GuideTitle", { fg = "#d79921", bold = true })
    pcall(vim.api.nvim_set_hl, 0, "GuideKey", { fg = "#98971a", bold = true })
    pcall(vim.api.nvim_set_hl, 0, "GuideInteractive", { fg = "#d3869b", bold = true, underline = true })
    pcall(vim.api.nvim_set_hl, 0, "MenuTabActive", { fg = "#3c3836", bg = "#83a598", bold = true })
    pcall(vim.api.nvim_set_hl, 0, "MenuTabInactive", { fg = "#83a598", bg = "#282828" })
    pcall(vim.api.nvim_set_hl, 0, "GuideSectionDivider", { fg = "#98971a", bold = false })
    pcall(vim.api.nvim_set_hl, 0, "KeymapGuideNormal", { bg = "#282828" })
    pcall(vim.api.nvim_set_hl, 0, "GuideCursorLine", { bg = "#3c3836" })
end

-- ==============================
-- 3. Funkcje pomocnicze i renderowanie
-- ==============================

local function format_section(title, content)
    local lines = {}
    table.insert(lines, "  " .. string.rep("─", 60))
    table.insert(lines, "  **" .. title .. "**")
    table.insert(lines, "  " .. string.rep("─", 60))

    for _, item in ipairs(content) do
        table.insert(lines, string.format("  %-18s │ %s", item[1], item[2]))
    end
    table.insert(lines, " ")
    return lines
end

local function get_tab_content(tab_name)
    local content_lines = {}
    local tab_data = GUIDE_CONTENT[tab_name]

    if tab_data.header then
        vim.list_extend(content_lines, tab_data.header)
        table.insert(content_lines, " ")
    end

    for _, section in ipairs(tab_data.sections) do
        vim.list_extend(content_lines, format_section(section.title, section.content))
    end

    return content_lines
end

local function is_interactive_line(line)
    local is_key_line = line:match("^%s*%S+%s*│%s*%S+")
    if is_key_line then
        local key = line:match("^%s*(%S+)%s*│")
        -- Interaktywne klucze to te, które wywołują akcje (np. <leader>, :, ENTER)
        if key and key:find("<leader>", 1, true) or key:find(":", 1, true) or line:find("ENTER", 1, true) then
            return true
        end
        return false
    end

    -- Linia, która jest czystą komendą Vima (np. :help {topic})
    if line:match("^%s*:.-%s*│") then
        return true
    end

    if line:find("ENTER", 1, true) or line:find("WHICH-KEY", 1, true) then
        return true
    end

    return false
end

local function apply_highlights(buf, lines)
    vim.api.nvim_buf_clear_namespace(buf, 0, 0, -1)
    vim.api.nvim_buf_add_highlight(buf, 0, "KeymapGuideNormal", 0, 0, -1)

    -- Definicja koloru tła bufora (z define_highlights)
    local BUF_BG_COLOR = "#282828"
    pcall(vim.api.nvim_set_hl, 0, "GuideInvisibleStar", { fg = BUF_BG_COLOR, bg = BUF_BG_COLOR })

    -- Podświetlenie aktywnej linii (GuideCursorLine)
    local cursor_line_idx = vim.fn.line('.') - 1
    if cursor_line_idx >= 0 and cursor_line_idx < #lines then
        vim.api.nvim_buf_add_highlight(buf, 0, "GuideCursorLine", cursor_line_idx, 0, -1)
    end

    interactive_lines = {}

    -- Podświetlanie treści i zbieranie linii interaktywnych
    for i, line in ipairs(lines) do
        local line_idx = i - 1

        if line:match("^[ ]*─+ *$") then
            vim.api.nvim_buf_add_highlight(buf, 0, "GuideSectionDivider", line_idx, 0, -1)
        end

        local title_match = line:match("%*%*(.-)%*%*")
        if title_match then
            -- Nagłówki
            local hl_group = "GuideTitle"
            if line:match("%*%*[ ]*GŁÓWNY PRZEWODNIK") or line:match("%*%*[ ]*PODSTAWY RUCHU") or line:match("%*%*[ ]*KONTROLA WERSJI") or line:match("%*%*[ ]*DEBUGOWANIE") then
                hl_group = "GuideHeader"
            end
            vim.api.nvim_buf_add_highlight(buf, 0, hl_group, line_idx, 0, -1)

            local star_index = 1
            while true do
                local s, e = line:find("%*", star_index)
                if s and e then
                    -- Gwiazdka znaleziona: podświetl ją niewidzialnym kolorem
                    vim.api.nvim_buf_add_highlight(buf, 0, "GuideInvisibleStar", line_idx, s - 1, e)
                    star_index = e + 1
                else
                    break
                end
            end
        end

        -- Zbieranie i podświetlanie interaktywnych elementów
        if is_interactive_line(line) then
            interactive_lines[#interactive_lines + 1] = line_idx

            local interactive_text = { "ENTER", "Terminal", "WHICH-KEY", ":bdel", ":q", ":q!", ":w", ":wq", "Eksplorator",
                ":e {file}", ":e!", ":source %", ":Clear", "Go to Definition", ":Hunk", ":ToggleTerm", ":Lazy", ":Mason",
                ":UpdateRemotePlugins", ":TSUpdate", ":CheckHealth", ":help {topic}" }
            for _, text in ipairs(interactive_text) do
                local s, e = line:find(text, 1, true)
                if s and e then
                    vim.api.nvim_buf_add_highlight(buf, 0, "GuideInteractive", line_idx, s - 1, e)
                end
            end
        end

        -- Podświetlanie klawiszy (np. <leader>ce, dd)
        for key in line:gmatch("<[^>]+>") do
            local s, e = line:find(key, 1, true)
            if s and e then
                vim.api.nvim_buf_add_highlight(buf, 0, "GuideKey", line_idx, s - 1, e)
            end
        end
    end

    -- Podświetlanie paska zakładek
    local tab_line_idx = 1
    local tab_line = lines[tab_line_idx + 1] or ""
    local search_start = 1

    if tab_line ~= "" then
        for idx, tab_name in ipairs(TABS) do
            local s, e = tab_line:find(tab_name, search_start, true)
            if s and e then
                local hl = (idx == current_tab) and "MenuTabActive" or "MenuTabInactive"
                vim.api.nvim_buf_add_highlight(buf, 0, hl, tab_line_idx, s - 1, e)
                search_start = e + 1
            else
                break
            end
        end
    end
end

local function render_guide(buf)
    if not buf or not vim.api.nvim_buf_is_valid(buf) then return end

    local saved_cursor_line = vim.fn.line('.')

    vim.api.nvim_buf_set_option(buf, 'modifiable', true)
    local tab_name = TABS[current_tab]
    local content_lines = get_tab_content(tab_name)

    local tab_line = "  " .. table.concat(TABS, "  │ ") .. "  "

    local header_lines = {
        " ",
        tab_line,
        "  " .. string.rep("─", #tab_line - 2),
        " ",
    }

    local lines = {}
    vim.list_extend(lines, header_lines)
    vim.list_extend(lines, content_lines)

    vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)

    vim.api.nvim_buf_set_option(buf, 'modifiable', false)

    -- Logika przywracania/ustawiania kursora
    local target_line
    -- Jeśli kursor był w zakresie i ostatnia pozycja jest prawidłowa
    if last_cursor_line ~= 0 and last_cursor_line < #lines and saved_cursor_line == last_cursor_line then
        target_line = last_cursor_line
    else
        target_line = 5 -- Linia 5 to pierwsza linia treści
    end

    vim.api.nvim_win_set_cursor(0, { target_line, 0 })

    last_cursor_line = target_line

    apply_highlights(buf, lines)
end

-- ==============================
-- 4. Funkcje interaktywne
-- ==============================

function M.next_tab()
    current_tab = current_tab % #TABS + 1
    last_cursor_line = 5 -- Zapewnia reset kursora na początku treści nowej zakładki
    render_guide(bufnr_guide)
end

function M.prev_tab()
    current_tab = (current_tab - 2 + #TABS) % #TABS + 1
    last_cursor_line = 5 -- Zapewnia reset kursora na początku treści nowej zakładki
    render_guide(bufnr_guide)
end

function M.highlight_cursor()
    -- Aktualizuje pozycję kursora po ruchu j/k, a następnie odświeża podświetlenie
    last_cursor_line = vim.fn.line('.')
    render_guide(bufnr_guide)
end

function M.next_interactive_item()
    local current_line_idx = vim.fn.line('.') - 1
    local next_line_idx = nil

    for _, line_idx in ipairs(interactive_lines) do
        if line_idx > current_line_idx then
            next_line_idx = line_idx
            break
        end
    end

    -- Cykliczność
    if next_line_idx == nil and #interactive_lines > 0 then
        next_line_idx = interactive_lines[1]
    end

    if next_line_idx ~= nil then
        vim.api.nvim_win_set_cursor(0, { next_line_idx + 1, 0 })
        M.highlight_cursor()
    end
end

function M.prev_interactive_item()
    local current_line_idx = vim.fn.line('.') - 1
    local prev_line_idx = nil

    for i = #interactive_lines, 1, -1 do
        local line_idx = interactive_lines[i]
        if line_idx < current_line_idx then
            prev_line_idx = line_idx
            break
        end
    end

    -- Cykliczność
    if prev_line_idx == nil and #interactive_lines > 0 then
        prev_line_idx = interactive_lines[#interactive_lines]
    end

    if prev_line_idx ~= nil then
        vim.api.nvim_win_set_cursor(0, { prev_line_idx + 1, 0 })
        M.highlight_cursor()
    end
end

-- ==============================
-- 4. Funkcje interaktywne
-- ==============================

-- Funkcja pomocnicza do bezpiecznego zamykania bufora/karty przewodnika
local function close_guide()
    -- Jeśli przewodnik jest jedynym buforem/oknem w JEDYNEJ karcie, zamykamy okno.
    -- Użycie "quit" zamyka okno/tab, jeśli to możliwe, lub kończy Nvim.
    -- Możemy też użyć 'bd!', co usuwa bufor i wraca do poprzedniego.
    local tab_count = #vim.api.nvim_list_tabpages()

    if tab_count > 1 then
        -- Jeśli jest więcej niż jedna karta, zamknij tę kartę
        vim.cmd("tabclose")
    else
        -- Jeśli to jedyna karta, usuń bufor, wracając do (pustego) poprzedniego bufora
        -- Używamy bd! zamiast tabclose
        vim.cmd("bd!")
    end
end

function M.execute_line_action()
    local line = vim.fn.getline('.')
    local actions = {
        -- AKCJE ZŁOŻONE (teraz używają nowej funkcji close_guide())
        ["Edytuj plik init.lua"] = function()
            close_guide()
            vim.cmd("e $MYVIMRC")
        end,
        ["Przeładuj plik init.lua"] = function()
            close_guide()
            vim.cmd("source $MYVIMRC")
        end,
        ["Pokaż/Ukryj Eksplorator"] = function()
            close_guide()
            pcall(vim.cmd, "NvimTreeToggle")
        end,
        ["Terminal"] = function()
            close_guide()
            local ok, toggleterm = pcall(require, "toggleterm.terminal")
            if ok then
                local Terminal = toggleterm.Terminal:new({ cmd = vim.o.shell, hidden = false })
                Terminal:toggle()
            end
        end,
        ["Pełny przewodnik Which-Key"] = function()
            close_guide()
            local ok, wk = pcall(require, "which-key")
            if ok and wk.show then wk.show() end
        end,
        ["Otwórz Lazy.nvim"] = function()
            close_guide()
            vim.cmd("Lazy")
        end,
        ["Otwórz Mason"] = function()
            close_guide()
            vim.cmd("Mason")
        end,
        ["Otwórz szybkie menu GitSigns"] = function()
            close_guide()
            pcall(vim.cmd, "GitSignsPreviewHunk")
        end,
        ["Przywróć (revert) Hunk"] = function()
            close_guide()
            pcall(require("gitsigns").undo_stage_hunk)
            vim.notify("Przywrócono fragment kodu (Hunk).", vim.log.levels.INFO)
        end,
        ["Pokaż autora linii (Git Blame)"] = function()
            close_guide()
            pcall(require("gitsigns").blame)
        end,
        ["Oceniaj wyrażenie/zmienną pod kursorem"] = function()
            close_guide()
            pcall(require("dap").eval)
        end,
        -- AKCJE VIMA
        ["Sprawdź stan zainstalowanych narzędzi Nvim"] = function()
            close_guide()
            vim.cmd("checkhealth")
        end,
        ["Aktualizuj zdalne pluginy (dla Nvim)"] = function()
            close_guide()
            vim.cmd("UpdateRemotePlugins")
        end,
        ["Aktualizuj parsery Tree-sitter"] = function()
            close_guide()
            vim.cmd("TSUpdate")
        end,
        ["Usuwa historie otwartych plików"] = function()
            close_guide()
            vim.fn.writefile({}, vim.fn.stdpath("data") .. "/shada/main.shada")
            vim.cmd("rshada!")
        end,

    }

    -- 1. Spróbuj wykonać akcję Lua (jeśli dopasowano opis)
    for k, v in pairs(actions) do
        if line:find(k, 1, true) then
            v()
            return
        end
    end

    -- 2. OBSŁUGA KOMEND VIM (np. :q, :w, :e!, :bdel, :help)
    local command_match = line:match("^%s*(:.-)%s*│")

    if not command_match then
        command_match = line:match("^%s*(:.-)%s*$")
    end

    if command_match then
        local cmd_to_execute = command_match:gsub("^{\\w*}", "")
        cmd_to_execute = cmd_to_execute:gsub(" ", "")
        cmd_to_execute = cmd_to_execute:gsub("%%", "\\%")

        -- Działania, które NIE wymagają zamknięcia (np. :w, :q!)
        local is_safe_command = (cmd_to_execute == ":q!" or cmd_to_execute == ":w")

        if not is_safe_command then
            close_guide()
        end

        if cmd_to_execute:find("{", 1, true) then
            cmd_to_execute = cmd_to_execute:gsub("%{.*%}", "")
        end

        if cmd_to_execute == ":e" then
            vim.notify("Komenda ':e' wymaga argumentu (nazwy pliku). Użyj jej bezpośrednio.", vim.log.levels.INFO)
            return
        end

        pcall(vim.cmd, cmd_to_execute)
        return
    end

    vim.notify("Na tej lini nie ma nic do wykonania.", vim.log.levels.WARN)
end

-- ==============================
-- 5. Setup bufora i główna funkcja M.show()
-- ==============================

local function setup_interactive_guide(buf)
    local map_opts = { noremap = true, silent = true, buffer = buf }

    -- Nawigacja zakładkami (H/L)
    vim.keymap.set('n', 'k', ':lua require("keymap_guide").prev_tab()<CR>', map_opts)
    vim.keymap.set('n', 'l', ':lua require("keymap_guide").next_tab()<CR>', map_opts)

    -- Nawigacja interaktywna (<Tab>/<S-Tab>)
    vim.keymap.set('n', '<Tab>', ':lua require("keymap_guide").next_interactive_item()<CR>', map_opts)
    vim.keymap.set('n', '<S-Tab>', ':lua require("keymap_guide").prev_interactive_item()<CR>', map_opts)

    -- Ruch kursora i odświeżenie podświetlenia (J/K)
    vim.keymap.set('n', 'j', 'j<cmd>lua require("keymap_guide").highlight_cursor()<CR>', map_opts)
    vim.keymap.set('n', 'h', 'k<cmd>lua require("keymap_guide").highlight_cursor()<CR>', map_opts)

    -- Zatwierdzanie akcji (<CR>)
    vim.keymap.set('n', '<CR>', ':lua require("keymap_guide").execute_line_action()<CR>', map_opts)

    -- Wywołanie Which-Key (<C-y>)
    vim.keymap.set('n', '<C-y>', ':lua vim.cmd("tabclose") | lua require("which-key").show()<CR>', map_opts)

    vim.api.nvim_buf_set_option(buf, 'undofile', false)
    vim.api.nvim_buf_set_option(buf, 'wrap', false)
    vim.api.nvim_buf_set_option(buf, 'cursorline', true)
end

function M.show()
    define_highlights()

    vim.cmd("tabnew")
    bufnr_guide = vim.api.nvim_get_current_buf()

    vim.bo[bufnr_guide].buflisted = false
    vim.bo[bufnr_guide].filetype = "keymap_guide"
    vim.bo[bufnr_guide].swapfile = false

    setup_interactive_guide(bufnr_guide)

    -- Ustaw początkową pozycję kursora na 5 (pierwsza linia treści)
    last_cursor_line = 5
    render_guide(bufnr_guide)

    vim.api.nvim_buf_set_option(bufnr_guide, 'readonly', true)

    -- Zamykanie (Q)
    --vim.keymap.set("n", "q", function()
    --    vim.cmd("bd!")
    --end, { buffer = bufnr_guide, noremap = true, silent = true })
end

return M
