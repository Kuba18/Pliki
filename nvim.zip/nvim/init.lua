﻿if vim.fn.has("win32") == 1 then
    vim.opt.shell = "powershell.exe"
    vim.opt.shellcmdflag = "-NoLogo -NoProfile -ExecutionPolicy RemoteSigned -Command"
    vim.opt.shellquote = ""
    vim.opt.shellxquote = ""
end


-----------------------------------------------------------
-- Appearance and Ergonomics
-----------------------------------------------------------
vim.opt.termguicolors = true
vim.opt.background = "dark"
vim.opt.number = true
vim.opt.relativenumber = true
vim.opt.cursorline = true
vim.opt.showmatch = true
vim.opt.scrolloff = 5
vim.opt.sidescrolloff = 5
vim.opt.laststatus = 3
vim.opt.showcmd = true
vim.opt.showmode = true
vim.opt.backspace = { "indent", "eol", "start" }
vim.opt.errorbells = false
vim.opt.visualbell = false

-----------------------------------------------------------
-- Basic Options
-----------------------------------------------------------
vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.expandtab = true
vim.opt.encoding = "utf-8"
vim.opt.ignorecase = true
vim.opt.smartcase = true
vim.opt.incsearch = true
vim.opt.hlsearch = true
vim.opt.clipboard = "unnamedplus"
vim.opt.splitbelow = true
vim.opt.splitright = true

-----------------------------------------------------------
-- Leader key
-----------------------------------------------------------
vim.g.mapleader = " "

-----------------------------------------------------------
-- lazy.nvim Installation
-----------------------------------------------------------
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "https://github.com/folke/lazy.nvim.git",
        lazypath
    })
end
vim.opt.rtp:prepend(lazypath)

-----------------------------------------------------------
-- Plugins
-----------------------------------------------------------
require("lazy").setup({

    -----------------------------------------------------------
    -- Colorscheme
    -----------------------------------------------------------
    {
        "morhetz/gruvbox",
        lazy = false,
        priority = 1000,
        config = function()
            vim.cmd([[colorscheme gruvbox]])
        end,
    },

    -----------------------------------------------------------
    -- Status Line
    -----------------------------------------------------------
    {
        "nvim-lualine/lualine.nvim",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
            require("lualine").setup { options = { theme = "gruvbox" } }
        end
    },

    -----------------------------------------------------------
    -- Fuzzy Finder
    -----------------------------------------------------------
    {
        "nvim-telescope/telescope.nvim",
        dependencies = { "nvim-lua/plenary.nvim" }
    },

    -----------------------------------------------------------
    -- Autopairs
    -----------------------------------------------------------
    { "windwp/nvim-autopairs",       config = true },

    -----------------------------------------------------------
    -- Commenting
    -----------------------------------------------------------
    { "numToStr/Comment.nvim",       config = true },

    -----------------------------------------------------------
    -- Snippets
    -----------------------------------------------------------
    { "L3MON4D3/LuaSnip" },
    { "rafamadriz/friendly-snippets" },

    -----------------------------------------------------------
    -- LSP + Auto-completion
    -----------------------------------------------------------
    { "neovim/nvim-lspconfig" },
    {
        "williamboman/mason.nvim",
        config = function() require("mason").setup() end
    },
    { "williamboman/mason-lspconfig.nvim" },
    {
        "hrsh7th/nvim-cmp",
        dependencies = {
            "hrsh7th/cmp-nvim-lsp",
            "hrsh7th/cmp-buffer",
            "hrsh7th/cmp-path",
            "hrsh7th/cmp-cmdline",
            "L3MON4D3/LuaSnip",
        },
        config = function()
            local cmp = require("cmp")
            local luasnip = require("luasnip")
            cmp.setup({
                snippet = {
                    expand = function(args)
                        luasnip.lsp_expand(args.body)
                    end,
                },
                mapping = cmp.mapping.preset.insert({
                    ["<Tab>"] = cmp.mapping(function(fallback)
                        if cmp.visible() then
                            cmp.select_next_item()
                        elseif luasnip.expand_or_jumpable() then
                            luasnip.expand_or_jump()
                        else
                            fallback()
                        end
                    end, { "i", "s" }),
                    ["<S-Tab>"] = cmp.mapping(function(fallback)
                        if cmp.visible() then
                            cmp.select_prev_item()
                        elseif luasnip.jumpable(-1) then
                            luasnip.jump(-1)
                        else
                            fallback()
                        end
                    end, { "i", "s" }),
                    ["<CR>"] = cmp.mapping.confirm({ select = true }),
                }),
                sources = cmp.config.sources({
                    { name = "nvim_lsp" },
                    { name = "buffer" },
                }),
            })
        end
    },

    -----------------------------------------------------------
    -- Debugging (DAP)
    -----------------------------------------------------------
    {
        "mfussenegger/nvim-dap",
        dependencies = {
            "rcarriga/nvim-dap-ui",
            "theHamsta/nvim-dap-virtual-text",
            "nvim-neotest/nvim-nio",
        },
        config = function()
            local dap = require("dap")
            local dapui = require("dapui")
            require("nvim-dap-virtual-text").setup()
            dapui.setup()
            dap.listeners.after.event_initialized["dapui_config"] = function() dapui.open() end
            dap.listeners.before.event_terminated["dapui_config"] = function() dapui.close() end
            dap.listeners.before.event_exited["dapui_config"] = function() dapui.close() end
        end
    },

    -----------------------------------------------------------
    -- Navigation: nvim-tree + bufferline
    -----------------------------------------------------------
    {
        "nvim-tree/nvim-tree.lua",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
            require("nvim-tree").setup({
                view = { width = 30, side = "left" },
                renderer = { icons = { show = { file = true, folder = true } } },
            })
        end
    },
    {
        "akinsho/bufferline.nvim",
        dependencies = "nvim-tree/nvim-web-devicons",
        config = function()
            require("bufferline").setup({})
        end
    },

    -----------------------------------------------------------
    -- Treesitter + utilities
    -----------------------------------------------------------
    {
        "nvim-treesitter/nvim-treesitter",
        build = ":TSUpdate",
        config = function()
            require("nvim-treesitter.configs").setup({
                ensure_installed = { "python", "javascript", "typescript", "lua", "html", "css", "c_sharp" },
                highlight = { enable = true },
                indent = { enable = true },
                autotag = { enable = true },
            })
        end
    },
    { "windwp/nvim-ts-autotag",           after = "nvim-treesitter" },
    { "RRethy/vim-illuminate" },

    -----------------------------------------------------------
    -- Productivity / Utilities
    -----------------------------------------------------------
    {
        "folke/which-key.nvim",
        event = "VeryLazy",
        config = function()
            local wk = require("which-key")
            wk.setup()

            -- Rejestracja grup (Which-Key v3 syntax)
            -- Uwaga: Konkretne mapowania (np. <leader>bn) są pobierane
            -- automatycznie z vim.keymap.set poniżej. Tutaj tylko nazywamy grupy.
            wk.add({
                { "<leader>b", group = "Buffers" },
                { "<leader>c", group = "Config" },
                { "<leader>d", group = "Debug" },
                { "<leader>f", group = "Files" },
                { "<leader>r", group = "Run" },
                { "<leader>g", group = "Git/Grep" }, -- Opcjonalnie
            })
        end
    },
    { "tpope/vim-surround" },
    { "mg979/vim-visual-multi" },
    { "iamcco/markdown-preview.nvim", ft = { "markdown" }, build = "cd app && npm install" },

    -----------------------------------------------------------
    -- Terminal
    -----------------------------------------------------------
    {
        "akinsho/toggleterm.nvim",
        config = function()
            require("toggleterm").setup({
                size = 20,
                open_mapping = [[<c-\>]],
                direction = "float",
            })
        end
    },

    -----------------------------------------------------------
    -- Dashboard
    -----------------------------------------------------------
    {
        "nvimdev/dashboard-nvim",
        event = "VimEnter",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
            local db = require("dashboard")
            -- Ustaw minimalną liczbę linii, przy której opcje będą widoczne
            local min_lines = 30
            -- Pobierz aktualną wysokość okna Neovim
            local current_height = vim.api.nvim_win_get_height(0)

            -- Podstawowe wpisy, które zawsze będą wyświetlane
            local entries = {
                { icon = " ", desc = "Nowy plik          ", action = "enew", key = "n" },
                { icon = " ", desc = "Szukaj plików      ", action = "Telescope find_files", key = "f" },
                {
                    icon = " ",
                    desc = "Otwórz plik        ",
                    action = function()
                        local file = vim.fn.input("Podaj ścieżkę do pliku: ")
                        if file ~= "" then
                            vim.cmd("edit " .. file)
                        end
                    end,
                    key = "o"
                },
                { icon = " ", desc = "Ostatnie pliki     ", action = "Telescope oldfiles", key = "l" },
                { icon = " ", desc = "Live grep          ", action = "Telescope live_grep", key = "g" },
                { icon = " ", desc = "Bufory             ", action = "Telescope buffers", key = "b" },
            }

            -- Wpisy configu do warunkowego wyświetlania
            local config_entries = {
                { icon = " ", desc = "Edytuj config      ", action = "e $MYVIMRC", key = "e" },
                {
                    icon = " ",
                    desc = "Sourcing config    ",
                    action = function()
                        local ok, err = pcall(vim.cmd, "source $MYVIMRC")
                        if not ok then
                            vim.notify("Błąd podczas ładowania configu: " .. err, vim.log.levels.ERROR)
                        else
                            vim.notify("Plik config przeładowany!", vim.log.levels.INFO)
                        end
                    end,
                    key = "s"
                },
            }

            -- Wpisy końcowe, które są zawsze widoczne
            local final_entries = {

                { icon = " ", desc = "Lista skrótów      ", action = ":lua ShowKeymapGuideInNewTab()", key = "k" },
                { icon = " ", desc = "Przewodnik         ", action = ":lua OpenOldKeymapGuide()", key = "p" },
            }

            -- Warunek: dodaj wpisy konfiguracyjne, jeśli okno jest wystarczająco duże
            if current_height >= min_lines then
                for _, entry in ipairs(config_entries) do
                    table.insert(entries, entry)
                end
            end

            -- Dodaj wpisy końcowe
            for _, entry in ipairs(final_entries) do
                table.insert(entries, entry)
            end

            db.setup({
                theme = "doom",
                config = {
                    header = {
                        "",
                        "",
                        "",
                        "███   ██╗ ███████╗  █████╗  ██╗   ██╗ ██╗ ███╗   ███╗",
                        "████  ██║ ██╔════╝ ██╔══██╗ ██║   ██║ ██║ ████╗ ████║",
                        "██╔██╗██║ █████╗   ██║  ██║  ██╗ ██╔╝ ██║ ██╔████╔██║",
                        "██║╚████║ ██╔══╝   ██║  ██║   ████╔╝  ██║ ██║ ██╔╝██║",
                        "██║ ╚███║ ███████╗ ╚█████╔╝    ██╔╝   ██║ ██║ ╚═╝ ██║",
                        "╚═╝  ╚══╝ ╚══════╝  ╚════╝     ╚═╝    ╚═╝ ╚═╝     ╚═╝",
                        "",
                    },
                    center = entries,
                }
            })

            -- Nadpisanie kolorów
            --vim.api.nvim_set_hl(0, "DashboardHeader", { fg = "#d8cfbd", bold = true })
            --vim.api.nvim_set_hl(0, "DashboardCenter", { fg = "#50fa7b" })
            --vim.api.nvim_set_hl(0, "DashboardFooter", { fg = "#8be9fd", italic = true })
        end,
    },

    -- Prawdopodobnie potrzebujesz też definicji ikon, która w twoim przykładzie była poza scope'em:
    { "nvim-tree/nvim-web-devicons", lazy = true },

})
function ShowKeymapGuideInNewTab()
    vim.cmd("tabnew")
    local ok, telescope = pcall(require, "telescope.builtin")
    if ok then
        telescope.keymaps()
    else
        vim.notify("Nie udało się załadować 'telescope.builtin.keymaps'", vim.log.levels.ERROR)
    end
end

function OpenOldKeymapGuide()
    local ok, guide = pcall(require, "keymap_guide")
    if not ok or not guide.show then
        vim.notify("Nie udało się załadować modułu keymap_guide", vim.log.levels.ERROR)
        return
    end

    -- Wywołaj przewodnik — sam zajmie się buforem i tabem
    guide.show()
end

-----------------------------------------------------------
-- LSP Setup
-----------------------------------------------------------
local lspconfig = require("lspconfig")
local cmp_nvim_lsp = require("cmp_nvim_lsp")
local mason_lspconfig = require("mason-lspconfig")
local capabilities = cmp_nvim_lsp.default_capabilities()

local on_attach = function(client, bufnr)
    if client.name == "omnisharp" then
        client.server_capabilities.documentFormattingProvider = false
    end
    -- Dodaj tutaj inne mapowania związane z LSP
    local opts = { noremap = true, silent = true, buffer = bufnr }
    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, vim.tbl_extend("force", opts, { desc = "Go To Definition" }))
    vim.keymap.set('n', 'K', vim.lsp.buf.hover, vim.tbl_extend("force", opts, { desc = "Hover Docs" }))
    vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, vim.tbl_extend("force", opts, { desc = "Rename symbol" }))
    vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, vim.tbl_extend("force", opts, { desc = "Code Action" }))
end

mason_lspconfig.setup({
    ensure_installed = { "pyright", "ts_ls", "cssls", "html", "omnisharp" },
    handlers = {
        function(server_name)
            lspconfig[server_name].setup({
                capabilities = capabilities,
                on_attach = on_attach,
            })
        end,
    }
})

-----------------------------------------------------------
-- Keymaps (Standardowe mapowania z opisami dla Which-Key)
-----------------------------------------------------------
local map = vim.keymap.set
map("n", "<leader>K", function()
    ShowKeymapGuideInNewTab()
end, { desc = "Pokaz skróty w nowej zakładce" })
map("n", "<leader>q", function()
    OpenOldKeymapGuide()
end, { desc = "Otwórz stary Keymap Guide" })

-- Window Switching
map("n", "<C-h>", "<C-w>h", { desc = "Go to Left Window" })
map("n", "<C-j>", "<C-w>j", { desc = "Go to Down Window" })
map("n", "<C-k>", "<C-w>k", { desc = "Go to Up Window" })
map("n", "<C-l>", "<C-w>l", { desc = "Go to Right Window" })

-- Buffers
map("n", "<leader>bn", ":bnext<CR>", { desc = "Next Buffer" })
map("n", "<leader>bp", ":bprevious<CR>", { desc = "Previous Buffer" })
map("n", "<leader>bd", ":bdelete<CR>", { desc = "Delete Buffer" })
map("n", "<leader>bb", ":Telescope buffers<CR>", { desc = "List Buffers" }) -- Dodane mapowanie

-- Files
map("n", "<leader>ff", ":Telescope find_files<CR>", { desc = "Find Files" })
map("n", "<leader>fg", ":Telescope live_grep<CR>", { desc = "Live Grep" })

-- NvimTree
map("n", "<leader>e", ":NvimTreeToggle<CR>", { desc = "Toggle Explorer" })

-- Clipboard
map("v", "<C-y>", '"+y', { desc = "Yank to system clipboard" })
map("n", "<C-M-y>", '"+yy', { desc = "Yank line to system clipboard" })

-- Config
map("n", "<leader>cev", ":e $MYVIMRC<CR>", { desc = "Edit init.lua" })
map("n", "<leader>csv", ":source $MYVIMRC<CR>", { desc = "Source init.lua" })

-- Debug (DAP) - Mapowania ogólne
map("n", "<leader>dc", function() require 'dap'.continue() end, { desc = "Debug: Continue (F9)" })
map("n", "<leader>do", function() require 'dap'.step_over() end, { desc = "Debug: Step Over (F10)" })
map("n", "<leader>di", function() require 'dap'.step_into() end, { desc = "Debug: Step Into (F11)" })
map("n", "<leader>du", function() require 'dap'.step_out() end, { desc = "Debug: Step Out (F12)" })
map("n", "<leader>db", function() require 'dap'.toggle_breakpoint() end, { desc = "Debug: Toggle Breakpoint" })
map("n", "<leader>dr", function() require 'dap'.repl.open() end, { desc = "Debug: Open REPL" })
map("n", "<leader>dt", function() require('dapui').toggle() end, { desc = "Debug: Toggle UI" })


vim.keymap.set("n", "<C-z>", "u", { desc = "Undo" })
vim.keymap.set("i", "<C-z>", "<Esc>ui", { desc = "Undo in insert mode" })


-----------------------------------------------------------
-- Funkcja do F6: nowe okno systemowe
-----------------------------------------------------------
function RunFileExternal()
    local file = vim.fn.expand("%:p")
    local ft = vim.bo.filetype
    local cwd = vim.fn.expand("%:p:h")

    local cmd = nil
    if ft == "python" then
        cmd = string.format('py "%s"', file)
    elseif ft == "javascript" or ft == "typescript" then
        cmd = string.format('node "%s"', file)
    elseif ft == "cs" then
        cmd = "dotnet run"
    elseif ft == "java" then
        cmd = string.format('javac "%s" && java "%s"', file, vim.fn.expand("%:t:r"))
    elseif ft == "html" or ft == "css" then
        cmd = string.format('start msedge "%s"', file)
    else
        print("Nieobsługiwany typ pliku: " .. ft)
        return
    end

    -- Uruchomienie w nowym oknie CMD
    if vim.fn.has("win32") == 1 then
        os.execute(string.format('start cmd /k "cd /d %s && %s"', cwd, cmd))
    else
        os.execute(string.format('xterm -e "cd %s && %s"', cwd, cmd))
    end
end

-----------------------------------------------------------
-- Funkcja do F5: float terminal w Neovim
-----------------------------------------------------------
function RunFile()
    local file = vim.fn.expand("%:p")
    local ft = vim.bo.filetype
    local cwd = vim.fn.expand("%:p:h")

    local cmd = nil
    if ft == "python" then
        cmd = string.format('py -m "%s"', file)
    elseif ft == "javascript" or ft == "typescript" then
        cmd = string.format('node "%s"', file)
    elseif ft == "cs" then
        cmd = "dotnet run"
    elseif ft == "java" then
        local classname = vim.fn.expand("%:t:r")
        cmd = string.format('javac "%s" && java "%s"', file, classname)
    elseif ft == "html" or ft == "css" then
        cmd = string.format('start msedge "%s"', file)
    else
        print("Nieobsługiwany typ pliku: " .. ft)
        return
    end

    -- Cała komenda w jednej parze podwójnych cudzysłowów
    local full_cmd = string.format('cd /d "%s" && %s', cwd, cmd)

    -- FORCE uruchomienie CMD zamiast PowerShell w toggleterm.nvim
    vim.cmd("TermExec cmd='cmd.exe /c \"" .. full_cmd .. "\"'")
end

-- Mapowanie F5
vim.keymap.set("n", "<F5>", RunFile, { desc = "Run current file in Neovim float terminal (CMD)" })

vim.keymap.set("n", "<F6>", RunFileExternal, { desc = "Run current file in external shell" })


-- Autoformat przy zapisie (LSP)
vim.api.nvim_create_autocmd("BufWritePre", {
    pattern = { "*.py", "*.js", "*.ts", "*.css", "*.html", "*.cs", "*.lua" },
    callback = function()
        if vim.lsp.buf.format then
            vim.lsp.buf.format({ async = false })
        end
    end
})
